import 'package:flutter/material.dart';

class ProfilPage extends StatelessWidget {
  final String username;
  const ProfilPage({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("PROFIL"),
        backgroundColor: const Color(0xFF80DEEA),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircleAvatar(
              radius: 60,
              backgroundImage: NetworkImage(
                'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUH1r7dz6tOTgcVKLcA2G_OWPry3d6QrUNeQ&s',
              ),
            ),
            const SizedBox(height: 20),
            Text(
              username,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text("Pengguna BuahinAja"),
            const SizedBox(height: 30),
            Text(
              username,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text("HALLO"),
             const Text("Perkenalkan Nama saya Nahwa Atika Manazil"),
              const Text("23670108"),
               const Text("email saya: nahwaatika@gmail.com"),
            const SizedBox(height: 30),
            
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text("Semester 5"),
                SizedBox(width: 20),
                Icon(Icons.computer, color: Color(0xFF80DEEA)),
                SizedBox(width: 5),
                Text("Prodi Teknik Informatika"),
              ],
            ),
            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // balik ke Beranda
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF80DEEA),
              ),
              child: const Text("Kembali ke Beranda"),
            ),
          ],
        ),
      ),
    );
  }
}
