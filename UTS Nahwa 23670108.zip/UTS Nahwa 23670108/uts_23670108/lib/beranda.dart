import 'package:flutter/material.dart';
import 'profil.dart';

class BerandaPage extends StatelessWidget {
  final String username;
  const BerandaPage({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("BERANDA"),
        centerTitle: true, // judul di tengah
        backgroundColor: const Color.fromARGB(255, 128, 231, 234),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {},
          ),
        ],
      ),
      body: Stack(
        children: [
          // === BACKGROUND IMAGE FULL ===
          Positioned.fill(
            child: Image.network(
              'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUTEhMVFRUWGBgWFRUVFxcZFRcVFxcYFxoXGBUYHSggGB0lGxcXITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0iICUvLy0tKy0vLS4tLS0tLS0rLS0tLS0tLS0tLS0tLi0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAQMEBQYHAgj/xAA+EAABAwIFAQYEBQIFAgcAAAABAAIRAwQFEiExQVEGImFxgZETobHBMkLR4fAjUgcUFWJy4vEWM4KSorLS/8QAGgEAAgMBAQAAAAAAAAAAAAAAAAQCAwUBBv/EADERAAICAQMDAwMCBAcAAAAAAAABAgMRBBIhIjFBBRNRMmGBFHEj4fDxFTM0kaHB0f/aAAwDAQACEQMRAD8A7glQhAAhCEACRKhAAkSoQAIQhAAhCEACEIQAISJUACEiVAAhCRACoQhAAhCEACEJEAKhCRACoTNS6Y17WOe0PfORpIDnZdTlHMSnkACEIQAIQhAAhCRACoQhAAhCEACEIQAJEqEACEIQAiVCRACpEIQB5c8DcgeaRlZp2cD5ELnnam/aLlzaxAy/hLtBBEiD5fNZBuLZqz2Bzi0u7gkwWwIj+dUitY3Nx29huvTbl3O6goXL+zeNm3qtaSQxxAc2dId+ePyxpr+y6gCmq7FNZKbanW8MEKvvsTFMwAXEb9B6ry3GqWQOJ1P5RqZCqespUnFyWUV4LJKotlfNqzlmRuDupKuhOM47ovKOCpEIUwBCEqAEQhCABBQvFWq1olxAHUmB7lAGTtbUXGLVK7tW2tMUqY4FR8l7vmR6LXrL9g7Isp16hcXfGr1agLjJyFxLdfU+61KhXLdHPySn3wCEiFMiKkSpEACEIQAISoQAIQhACIQlQAiEIQAIQhAAhC8veAJK43hZYA94AkmPNQ62J0xsZPQKFeXGY/QKvczvfUrD1fqk4yxUhmNHGWUvaeg2qHvqc7egjT+cKkuOyxqMpfBy03aOc7YgEDURz4K47QzULaLN36eAaP2Vw0ZadQj8rHR6NKxoXWRmpJ+f7jKzHGDnllg1xVrU25szH5wakfhLQ78QHkF0nEO1DKQayl3soAJMwIER5rNdgqmUZDsZj3gqJ2ptHMru2DHAPBO2sy0dTIKeeuucWoPHjJXqMt8k2niLnuLnOJJ1mfon61x3m694/T9VSYZTDQC45idhsAOJ6lXBtcwBygHgifn1WZtbbWci2Cxtrt7AXB5AMTpGg6HXqn//ABHUcAGuAjd0CT6LI2eK/Ec5jTto4T8lNuQGsziABuB4eBUlffWtkW4v4DBof9VfIl+vUHT24V7h+KtfAO+2bglYCjRqOaHj/wBpIBjw1Vthd7oBt9ZTOm9Quqn1PKf5O7Vg3q8VKrRuQFm6vaF9Id4B0dTBKh1cZ+K4uGg4B3jgLYv9YprhmPL+CCgbJrwdjKVUOEXzATLoblB14M8KcMZozGaPEjT3TWn19Vlak2ln7nHHDJ1R4aCToAJPksHiuKm4rRJDGHRv3KuO2uJ5KYptPefrAOuX9J+ix1g8bxII221SHqmtcX7UH+5dVHCybXs9ekOFExliWxx+y0Sw9N5bUo1IgCNvHf5FbgJr0y1yqcZeCFscPIIQhaZUCEIQAIQhAAhCEAKhCEACEIQAISJUACRCQlAA4wqi/u5MDZer+8nQbKuptLj4clYmt1m9+3Abpqx1M902F3l1Xi7OVuilk8DYKqxWoXdxurnaALE1DwsLuMRWWVeFM+JVc86xoPAf91dYgyLd3jp7kBe7DD20mBo1PJ6lSsStM9JzRvGnmNR9FXCqST/YJSTkjC4KcgkH8D3A/wDF37ge6vu0Vj/m7cOpjvsOZo69W+v2Cy9q4ioW/wB51Hz+y3eEU4pgHXdcrcvcx8k7oI5TQxplM5apLSDGoPHBG4V1YYz8aQwnKDqdRPgJWo7VdjLe87+UMrgd2oOfB4/MPHcLnVo91q99GrLCDr5/odDKcsphjMc7hOUS+rWFOkc1JgYTJMbOJ1M9T4qlHaOm4tAcDJEgcCeVIvseDm5WOzaRPAkQfMwjsrhNsS6oWMJaYEiRxxtOqgoxUXO3OSKTNRSv2xIjZU/+plr3EA5Z3jRP9orFmVr6ZywZIboCOhCjWVdkQ7p80rGiMfuRk2WdhdCt33wWjQA/XTdS7pkGGhonURAbH0Cxbb40Kj6Y1ZOYeAdr91Mo44x346bnsghwDixxBEaOGyu/Tyb2v6X5OF2y+bnyhzXECYB4zObPiCWmDsYkKzF8MpaG53O7rRGsnoOqzeFO+I3LAaxrnZHBrQ9wJmXkDUxA3jTQBaXB8WpW1OsXsaHspuex5HedA0bJ6kjZTr08Hfsi8L/c6+/Bl8SunurODnfgIpT0FMBse4K9Me5mgMiZkhVWFXGeS6Z1cY6nVXFm4B5006IveGxhPHBqfjPcxkDj7bwtvbvlrT1APyWJbcMawZdttPHdS6/aU06bWNGoG++kmI9Fp+nXqE5Z8pMrlW54wjXoXMsQ7aljgM7sxjTwmNlbYd2qeIznOPn7rT/XV5wzj0k0sm3QmLO6bVaHsMgp9OJprKFmsAhCF0ASpEIAVCEIAEiEIAEIXipVA3XG0llgenOhVl7d8BJdXRKgBpqGG+p4CxtXrHPogNVVY5keAC8wPU9FLLQBAXttMNED1PJTFQws6S2L7l+dwzcVcoTGGUCSajudG+XJ9T9F5LDUdlGw3KtGsgQNglow3S3Mm3hYFbun82iaaEpdATEFhZKXyYC/phuIPbxGcf8AqA+5K19i/uhYjELjPiVaNmta35N+8rY4e/uhJvpt/A5NdKLgahcv/wAW7WAyu0az8N/sS0/Ij1C6Y1+i53/iPdtdQe09QfZw+0p7dicH9xaMM5OY2td4GWC6TpG+vC1fZ+yr05cXQHR3d4PmouBWzQ34jhvsPDqrV9/GjdloKEJ53Icp0nGZE6tQzCKlQkcj9k5RsqPB+araTS7eVIp25HJXfZriuIlr08WS3YLQcZgT15TVXA2tB+GY8NwlpucE/wDEclLtq8Cl1CXYo6VR9GGO454T+LYmHW5Y+IEx1k8BWZqOa4VGwHN1EgH0IO43WFxc1Kl491YNbmOZrWCGBuwytHlr4yqKa4zk3nDX/Ikq+otMBJAO8nQbStNb0xqSdevCztnWAOkfuru0qDLPEaD9+UtqU28ls0XVJxyNzagO8oAULtOfgtY9p7slp8J1b6Qn6FcFu8R9+f51Ue/c2rSdSeRDhvtDpkOjzhRha1OPxjBZBvsV1C7ZUjNB8wrahQcR3RIWBw2hcucQKbu6cpOzZBg946H0W77OuqskVJHkJny4WjOcIPE2i9xljg1XYu8LS+k7pmH0P2WnF13gDz/NVirCuxhJGfMTuGjQdBqrR15PJ9tVTL1r2Eox5SFbNO5PJqkJi1uA5oMiSBI5B6J9eorsjOKlF5Qg1gEIQpnBUIQgASIKhXV1rlbvzCquujVHMiUYuTwh6vcAaDdVteuSepK9/DJ30+qUQ3b35WNdqJWfVwhiEVHtyxltrOrz6D7lPZgBA0CbfVUatXASM7lFdJaot9x6pUUXKahhu3J4H6r3StnP1fIb05P6KboBA0AUFFy5nwiTklwhujSawQPU9SvbRKSJXouhTzn9iB6Omig4ndtpMc92zQXHyAlOVrgBc/7e4yXRbU9XOIL492t9dz6Kt2Kcti/pFtVTbK3s0XVH1azt3v8A+o//AG+S6DZtgAeCzWBYfkaxnQanqdz81q7dqRss33OS7DNjHripDD5LkPa+7zvyHYmP1XU8Wf3CG6k7DlctxPsve1KweKYyid3tn2lP0Si7FueMI7RFeRtjdAAnTaECfknnWNaj/wCZTcB13HuNE9eXbSNI228VrVSi45TNLdzwMW90BorS2qZlmTVkmN+qtsLuIInjhG/wyFscLKNHSsdJjVeTQBlS7O4BG6fICJ1qRlTm/JS1KJ191lu0dIZA8btO/gdCPeCtbixDRvGiwGOXZcfhN3cYHvus+ut+9wUYbeUPYSx1Tu02lztNB5rY2fZ+qBDnhnWJMD5KBgrmWzGtpiSBLjy4nr+nRaO3xNznAEEkztoP5+qYlTGXLND9I8ZZBt8NMmX6g5dpB4zb7HePFRr7AKzu817XgHbVriBroNZ5V3WsxByudTJGumZsT0/fokF6yiANXkddPWFCFDbxJcfIKpt9KKinetGmykU7zxVBjVAy5/4Z2I69PsqzDcQe57WTuYP3SFmg7tGi6Nqyb+1qFx0VxRaBvr18+iqMPEAfXoOqk/5wTlbsFiWRy+BKcXN4XY0NnEbDRXNm8kQeFmMMr98eIPuNf1WlsNj5/QBei9Bk8pL75MjVR2kpCEL1gkKvD3gbqLjOJ07ai+vVJDGCXQJO4AgeZCp7PF2V2CqxwcHcg7dR4Qk9Zq1p45wWV1uZdVLscKLm6KL8YLy65A5XnbvUnN9TGo047Epz1HqVlBrX5JhoJPAGpXunhb361XZR/a06+p49Eqrp3PoX58FuxR+o8m5LzlpjMeeg8zwpttZhneecz+vA8h909SptYMrBlHQJSVbtjXy3lkJSzwuwj6i8ByCm6lQBVTm+8mdij26rCr7m/hRb29WZxfGRTBJOvRKu2y17YDVdK7sl9oe0Iosnd5/A3x6nwCoOzVi5zjcVdXOktnfXd3rwqzDrZ91V+LVnJwOscDwWzpQPRX2JUQ9uP1Pu/wDov+yLG0AaJO5XqvXfGpygmABvPiVFFaNefomrgkiT1BnwnX7pSBZGrnknsLWmRr5pwXfgFAD423Xo1QNz7I96a4XB11J9ywFZrhBCzmP9k2VgXUTkfvH5HeY48x81dUsvJPt+6fB/tPv+ynHUWV9SZWm4PMTkzqT6Tyyo3K9u4P1HUeKk0K4Gq2narBxXpFzR/UYJaeo5Z6/Vc6Y/nhbuj1MdRDd5XcYc965Ndh114qxddxysfRvABunv8+52jZPkmJWYXBm3Lkm43f8AdJ+awljc57guOzVdYpQuXtIZScZ8vuVnm2T7fL8SWueMxaRtB0E8nn1Vumq6XJ92GlX8aKfY2FpdhxBmDwOCYWvwi3yZcxk8k8cz7/Rc4s7vURpG/iVucDvw78WukGVXe9kTcvTxx2NnQdMCBEDjeU0MPbUJEfslsrtpAj+fyElteZavGs6+8fIKGltUn1GViaztKvH8Pa1rpA2g9J4I9Vz17fh3YHWCPoV0TtPiLQDOsyIXJrys6pWzNPJ153n9FfZGMspGpplOVPUdDqYwxoygyeYUSljdNh75PsqXD20qbf6jjPhqSfNSnWDagOV0ka+I8VlR0Ee3gvWmrhxLJvOy96ytVYWOkajkQSFvqLMoAXz/AEq9xQgtdo0jQCD56LoHZ/t+1zg2qdDpP7rW0Gnr0qa+TF9Q9Nsm99XK+DoaF5pvBAIMg7FelsHnhm+tGVqbqdRocx4LXNOxB3C5Zg+BXVjWq0zTPwSSWVAZBAJifEg/JdZleXJXV6Zaip1t4yW1WODyYE3B6qbYWLqneccrfmfLorDtMbWhTNasAwZg0HWC5x0EBRrXHKFQRTqNcQBoN9fBeSt9L/TSzbyv67mgr3OPSizoU20xDAB9T5nlKairHXklPUqyqWr3dMeER9ryyYSvJcmjWTFa4hRndFAoMeq1oVPfXkcqFi+NspjvGTw0b/ssld3de4MAFren83VUa538y4iMwrwSsVx4ahpnx/Tqqihhr67s1X8O4byfP9Fa2OCBurtT4qyJawSSGgbk6AeMplWxrW2rv8luQoUg0AAeieadU1UrNAkHfZRrG5D3OHRLuLabLKo5kW7ACot5cw0B2aNZIEkDU6CdfJS7ceHvsm7iiHEtIBE68jfxRDpSeOC2XOUV+F16lYZnHTgiJM8OO2ngrOi5rdITLsrG5WgN6ARx4cLwKmy5d1vK4ROEHtwyypaqZ8A7wf56Koov10MK/tK+Yd4AefP6/su0UQszGQrqN0OURCFx/tzaPoXhYwaVe+zwknMPQyfIhdiuDrKwn+IDW56Dvzd9vocp+yu9Lm6dS4900/5BFOa4Mzh+FgQXnM7/AOI9OfVX9vSA2Cg271Op3AW3ucuWVT6XhE5gTN5aNqNLKjQ5p4+46FFKui5ud4U0vJXGTyc/vqRtqxbu3dp6jx8RstZ2QtatwcwOVmzndYIMBUOIWhuKzGTpm1PRvK6DYONMNpU2ANHsGgaE+qttalFLyaVdk3HBpbO2pUwBJKmto0nHYT/OVSFjiNO8Rv5p+zv9cnLYzHYeSoUdvjArOtvlMaxjAKNRpmR0IJBG+x25XO8S7K1bXNUZNSnvP5mj/cBx4hdWqVi4Q30jhev8tIId66aIcnHt2LqNXOppy5OJ/wCaaGmNz7K6wG9ZRZ8d7tyaZETuNNOdYXjtvggt6oewQyoTp/a7ePUa+692eFtrWZB7pa7NI/F1HzVynDZz5Ne+asq3R8lTd4pVFZ4MjX8JH5Tr9IK1+GWTatL4jWzG8eKz2OYSKRY99QuL2jvQBOgjbSIWq7G3OSiWH8Tth/tC45KUMrsUubVKlHubvsPeOcw03T3QInfoft7rUrLdkaEOcfD6rUrT0rbqWTyOu2+/LaBC8EL2V5cr2KlR2jwll3b1KD9A8aOgHK4atcAeQVy7B+y91a3Tg6MoEF+7KgnQt5EDgrsD1VXNMklK6qr3a3D5L6p7WUwcpFN4Ccq28cKNUprzv+CqL+ob97J4u8RawcnyVBd4pVqnKzQeH3KuqlKeFjcYqVre7bBBpVRo3LAaRAOvXnyKjP0zam4vOPkthavKJlPDhMnU9T9lY2hpB/wwQXhuYjoJiSopqgu8EzZXAa1z+XuLvTZvyA91myUpRbZfuyWl1UACpL26a4OY4Agggg7EHgquxfGgPzQs/UxYEPcD+FsnzPdA9z8k3ptFN4kT2NRyybSvHUqbWFxc3KMpO40/CfDoneymJZq1RpO4Dh6aH6hZJ1858k8bDj+QiwuTQqsqwQJ1af7TofktiWi3Qlnuy+vowdntq8CfsvDKxE7bb88z7qDZ3Ic0OBkEAg+BC9vqfdedScXhl+xNnmpU1lK2omS6UNMLrXBdwTqdTVWlrcGIn9/51VLTcplGqAqZZj2Kba1JFhUeub9vbo1LmjSpAuc0OJA4kga9NitH2j7QCi0MZDqrzlY3xP5j4BM4ThoaA5xlx/E87lyc0NbqfvTXfOP/AEQ1FyojjyUtjhNcjUDy3T7rZ7NS0+ivK+MNYQxozOGpHSI6eB+YU+zuaVfTKQ7KHQRwZ2PPHuFpZtxuwZj1U28sygvWqtxTEAxjWsky3U9TJBPhqJ9VpO0WABzS5mh4P69QubXty7I9pEOpO1B3h3dPs4N90zp37n47ouhbFrJddmKhdVceYA99T9AtxdXAgUh6kHUlcv7J3sVCP7iPuukspNqPnNJPG/2VuoWzLNWuSdSl+55oYtlcQx4zkjQnfg/JTql1ID4iTq0dfFZHGcDc6oZMaEsgwS7gSPHor+hUfTt8tVpc8NAzxoSPpISiktqWe5CmzMsYNfgN43Y/Lqrq7aA3MAesLm2C4ptkEDSOB468LdNv2uYNd01DEoNSIavTOFikih7V2DK9u9o0cBmbO+Yagfb1WMt7lpY0AxpPr5LoxAyuBiIPt1K5Lh+FvIBBkETM6e6odGUaGjsSi4yZZ4hUbXtWNJl9NxaD4AnT2I9lN7NscCGjU7JrDMBq6gMLi4yAAf4V0nsf2V+D/UrDvcN6eJTmmoeHH7kNXrK6YvD/AAaLBLT4dMTud1YoQtOMVFYR5Gc3OTkwSEL0hSIjRYvDqQT5XkqLR1Mra9rqoFe1hXFZ/RQaqqlFMtjIqH0lk+3OKUqFNrXs+I9xljc2WI/OSNh9VunLlHb2sxlzcOqU87yymyhOrGAglzo69PVLyqQ/o4qyxKRBsMephhz0alNxEsc0l1N3mCJHmJVi6mKrP6NZrgIBiQR5tOoWItMSqM0Djl6biOmq0/ZpjXXrjQa4UjTMgzAMN6/7tkq9JXJ9jU1GmjCLnF4IVlgvx69Sk+sym5oluf8ANoSY403VfRtaOZzHv/EQ1r9mbwHO5jWVM7V2sXGfggAjjTlU9SDsEzGvCwhmi+E6ut+O3wRHO+BU0DXQSIPeaSNPUJu8rOO8eitqPZx9YAt3Vhh/Y5xd/VcYH5WxmP8A+R4ldsnGuG6bELNTBOWB7svipa0UiCQAO8ASGnkHoFZXWMBroJCsnD4FHKwNZAgM01+5PM+Cz1SiDOUFwG8jQagS6REnVZPt13zc0jQ9M/iwcn28FnRxRp2IUn/OjdY65w94cPh8/lJjXpJgT4Jiu65Zo5rx9PcaIfp6fKZfZsi8Phmz/wBRg7qNiXaQUwQ0FzugBPqqCw+Iwgl3nlAzQI2kb+K11HtA12lOk0bgl7gXaeW+nMrn6KCee4rdDUqXTDj5yZXs/TfXuRWqmTqQOmkT81u8V0od3fbbroeRpH0VPcsDX067GgMLjSqdQ5wzNcfAyB6jqra/tHVqXd3A2nWSuXS3WxeMLB5zVOXuvd3JP+GuGMqkueCS0aTq0gkxPurbtVhjbbK+nsXQRrofCAdNI10VDhGIV7UZWtIA1j8pIGxgabaL1j2PV7r+m2QHafhcBrOoduCNfkNyE81wVFpTqF7dY2EiQd/EEyuY9s6Ap3Ic1olw70iZAMajnj2C6RhdIsZ3tDuRPP3XNO3V6H3eVv5GwfMkuj2ISul/zuO3IxoUnbh9irdlpMLchaHxUY4DY693XWNwD0K2XY3FGugOMAaSfJY2tdOdScx0u7zYJJJEB2glM0Lo0nAAxMeUrTnH3Im1GMa81+GdmunUoGYg8jzHRVGM4pIDaTZEZtZkk+Ph0WYsbyo7QzGkEnw/7qcKrmnrPG+6TWnw+C2FEa3l8j1i/MZDQ3k9deVrrG4BEkdN+NtliH4g2m4zBMf8T6iNVedl6guCcrh/xzCfQKcYPOEW34cNz7Fri+IFtJ5ie6YHoT7QCfIFcpoA13AEgcAEw0Df3/VdFxdtUB/dJHeZA2iId+noVzltg4EgA6dVcoYRTo7IOTk+3g0fZu8uLO4YWlzR3T8Oc1OrTmHSJ7pyyQY4X0FTXIv8PuzVS5yOuJ+FRnIIjNmIOUO3Ilo8uN11M2L2606zwf7anfafOe97OTlScV2Mb1W2E7enHHlE9CYsq+dgcRB1DgDMOGhE+YT6uTysoyhUIQugIvD0IQA06mm3W0oQuYO5I9WyMaLI9q+yJuQDEPGzh06EchCFz20yyu2UHlGOZ/hvcZtQ0Drr9FuuznZUW7MsanUnkoQuquK5LrdZbasSfA/iHZGjV/GwKtZ2BtmmcgQhd2r4KVOXyWlrgVKno1oCgY7h0NLmAaCSBoTB+eiEJXV1RnS0yUeXgw2PYgalJrSe8YOvIMgac8+5WepPI8juHAaEAtkGNxPCELNoWIo9l6X/AKWIXVwHDvb8+P19zGgGmiabib6sMdBjmJkcSOdoQhMfJdfCLlHK8lm5jRT0yzHEg7+x2OvTTdM2JPxWDXQjoNjw3nYpEKvyhiP0y/JZY3cVPgOpv0zuzucdXS1stAO2hY3UdFK7OdomvaGuIDxo7z6oQi6iNkG34PL6ymDsxjujVU8Qa4awfNNsqU2ghoGp1HoB6bBCFjuUk9uTKdS3YKjHcYLGlrRL47rfufBcyFtUFV5qE5zL3O51kzptrohC3aNPGurK7s0fT0o34Rbsvrd+UVKcO2LyS4eeWZU/tRg1u6jSqW7w74ji3LGUggSSB9vFCFODybl8cR4+/H4ZSWNvXpmAdOhWlwnDKlUwahbPQa+hQhMbE2YjvnGPDJPbHs3QtLQVJdUq1KjaYc4ghoguJA8mx6rNNtmUn5Xuio0jVveYJAMEjWRO4QhU3ra+DV9LbthifOcmzwDtBesplw+Hc0KZHxGkD4gad4doSdzJnUrq1DBrdwFQU26gEGODqhCt07bXJl+r1xqliCxzjjzwmWVKiG7JLuhnY5gc5mYRmZGYTyCQYKEJkwsjeGWQo0mUmlzgwBoc4y4xy48nxUpCFxLAH//Z', 
              fit: BoxFit.cover,
            ),
          ),

          // === CONTENT DI ATAS BACKGROUND ===
          SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 20),

                // HEADER
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Halo, $username",
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 3, 3, 3), // teks gelap
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        "Selamat datang di BuahinAja 🍉",
                        style: TextStyle(
                          fontSize: 16, 
                          color: Color.fromARGB(179, 12, 12, 12), // teks gelap transparan
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // MENU UTAMA
                const Text(
                  "Menu Utama",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 3, 3, 3), // teks gelap
                  ),
                  textAlign: TextAlign.center, // rata tengah
                ),
                const SizedBox(height: 20),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // PROFIL
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ProfilPage(username: username),
                            ),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                          child: Column(
                            children: const [
                              Icon(Icons.person, size: 40, color: Colors.white),
                              SizedBox(height: 8),
                              Text(
                                "Profil",
                                style: TextStyle(fontSize: 16, color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // DATA
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: Column(
                          children: const [
                            Icon(Icons.list, size: 40, color: Colors.white),
                            SizedBox(height: 8),
                            Text("Data",
                                style: TextStyle(fontSize: 16, color: Colors.white)),
                          ],
                        ),
                      ),

                      // PENGATURAN
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: Column(
                          children: const [
                            Icon(Icons.settings, size: 40, color: Colors.white),
                            SizedBox(height: 8),
                            Text("Pengaturan",
                                style: TextStyle(fontSize: 16, color: Colors.white)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
