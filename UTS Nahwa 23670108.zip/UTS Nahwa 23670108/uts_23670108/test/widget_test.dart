import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:uts_23670108/main.dart'; // sesuaikan nama project

void main() {
  testWidgets('Halaman Login menampilkan teks dan tombol', (WidgetTester tester) async {
    // Build aplikasi
    await tester.pumpWidget(const MyApp());

    // Pastikan AppBar ada dengan teks "LOGIN"
    expect(find.text('LOGIN'), findsOneWidget);

    // Pastikan tombol "Login" muncul
    expect(find.text('Login'), findsOneWidget);

    // Pastikan ada 2 TextField (username & password)
    expect(find.byType(TextField), findsNWidgets(2));
  });

  testWidgets('Masuk ke BerandaPage dengan username', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    // Temukan TextField pertama (username) dan masukkan username
    final usernameField = find.byType(TextField).first;
    await tester.enterText(usernameField, 'UserTest');

    // Tekan tombol "Login"
    final loginButton = find.text('Login');
    await tester.tap(loginButton);

    // Tunggu navigasi selesai
    await tester.pumpAndSettle();

    // Pastikan BerandaPage muncul dengan teks "Halo, UserTest 👋"
    expect(find.text('Halo, UserTest 👋'), findsOneWidget);

    // Pastikan menu "Profil" muncul
    expect(find.text('Profil'), findsOneWidget);
  });

  testWidgets('Tombol Login tanpa username tetap pakai default', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    // Tekan tombol "Login" tanpa isi username
    final loginButton = find.text('Login');
    await tester.tap(loginButton);
    await tester.pumpAndSettle();

    // Pastikan BerandaPage muncul dengan username default "User"
    expect(find.text('Halo, User 👋'), findsOneWidget);
  });
}
