package com.example.uts_23670108

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
